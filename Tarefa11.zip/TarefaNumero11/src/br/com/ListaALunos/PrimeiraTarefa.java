package br.com.ListaALunos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PrimeiraTarefa {


	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		listaSimplesAscendente();
		exemploNumeros ();
	}
		public static void listaSimplesAscendente() {
			System.out.println("++++ Lista de nomes em ordem alfabética ++++");
			List<String> lista = new ArrayList<String>();
			
			lista.add("Lucas Antônio");
			lista.add("Marco de Paula");
			lista.add("Luís Cláudio");
			lista.add("Sérgio Marques");
			lista.add("Antônio Carlos");
			lista.add("Mariana Gonçalves da Silva Reis");
			Collections.sort(lista);
			System.out.println(lista);
			System.out.println("");
			
			}
		
		private  static  void  exemploNumeros () {
	        System.out.println( "****** exemploNumeros ******" );
	        List < Integer > numeros = new  ArrayList <>();
	        numeros . add ( 1 );
	        numeros . add ( 3 );
	        System.out.println( numeros );
	    }
		
	}
	


