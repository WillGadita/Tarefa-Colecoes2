package br.com.ListaALunos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SegundaTarefa {

	public static <T> void main(String[] args) {
		// TODO Auto-generated method stub

		List<Pessoas> lista = new ArrayList<Pessoas>();
		Pessoas lucas = new Pessoas( "Lucas", "Masculino");
		Pessoas altair = new Pessoas("Altair", "Masculino");
		Pessoas edgar = new Pessoas("Edgar", "Masculino");
		Pessoas sandra = new Pessoas("Sandra", "Feminino");
		Pessoas amélia = new Pessoas("Amélia", "Feminino");
		Pessoas luana = new Pessoas("Luana", "Feminino");
		
		lista.add(lucas);
		lista.add(altair);
		lista.add(edgar);
		lista.add(sandra);
		lista.add(amélia);
		lista.add(luana);
		System.out.println("Lista de Pessoas separadas por Nome e Gênero:");
		System.out.println(lucas.toString());
		System.out.println(altair.toString());
		System.out.println(edgar.toString());
		System.out.println(sandra.toString());
		System.out.println(amélia.toString());
		System.out.println(luana.toString());
		
		
			
		}
		
		
	}


