package br.com.ListaALunos;

public class Pessoas implements Comparable <Pessoas> {

	private String nome;
	private String sexo;
	
	// Construtor
	public Pessoas(String nome, String sexo) {
		
		this.nome = nome;
		this.sexo = sexo;
		
		}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
    
	
	
	// Método To String é para fazer impressão no console.
	@Override
	public String toString() {
		return "nome: " + nome + " - sexo: " + sexo;
				
	}
	
	
	
	
	
	@Override
	public int compareTo(Pessoas o) {
		// TODO Auto-generated method stub
		return 0;
	}

    


}
	
